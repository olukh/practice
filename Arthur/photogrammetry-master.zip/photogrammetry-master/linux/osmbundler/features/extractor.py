
class FeatureExtractor():
    def __init__(self, distrDir):
        pass

    def extract(self, photo, photoInfo):
        pass