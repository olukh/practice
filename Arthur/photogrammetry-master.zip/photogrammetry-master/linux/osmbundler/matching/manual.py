from engine import MatchingEngine

className = "ManualMatching"
class ManualMatching(MatchingEngine):
    
    featureExtractionNeeded = False
    
    def __init__(self):
        pass

    def match(self):
        pass